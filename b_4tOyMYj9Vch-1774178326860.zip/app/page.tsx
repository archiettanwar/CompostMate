import LoginSignup from '@/components/login-signup';

export default function Home() {
  return <LoginSignup />;
}
