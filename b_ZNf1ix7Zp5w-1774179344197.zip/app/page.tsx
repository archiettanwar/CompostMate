import DesktopDashboard from '@/components/desktop-dashboard';

export default function Home() {
  return <DesktopDashboard />;
}
