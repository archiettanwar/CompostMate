'use client';

import { useState } from 'react';

export default function LoginSignup() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log(isLogin ? 'Login' : 'Sign Up', { email, password });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 relative overflow-hidden">
      {/* Decorative Greenery Elements */}
      <div className="absolute top-0 left-0 opacity-30 pointer-events-none">
        <svg width="300" height="300" viewBox="0 0 300 300" className="text-primary/20">
          <path d="M150,50 Q200,80 220,150 Q200,120 150,150 Q200,180 220,250" stroke="currentColor" strokeWidth="3" fill="none"/>
          <circle cx="150" cy="50" r="8" fill="currentColor"/>
          <circle cx="220" cy="150" r="6" fill="currentColor"/>
          <circle cx="220" cy="250" r="8" fill="currentColor"/>
        </svg>
      </div>
      <div className="absolute bottom-0 right-0 opacity-30 pointer-events-none">
        <svg width="400" height="400" viewBox="0 0 400 400" className="text-primary/20">
          <path d="M350,350 Q300,300 280,200 Q300,250 350,200 Q300,150 280,50" stroke="currentColor" strokeWidth="4" fill="none"/>
          <circle cx="350" cy="350" r="10" fill="currentColor"/>
          <circle cx="280" cy="200" r="8" fill="currentColor"/>
          <circle cx="280" cy="50" r="10" fill="currentColor"/>
        </svg>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Card Container */}
        <div className="bg-card rounded-2xl shadow-2xl p-8 sm:p-10 border border-border">
          {/* Header Section */}
          <div className="text-center mb-10">
            <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 mb-4">
              <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Outer Circle */}
                <circle cx="40" cy="40" r="36" stroke="currentColor" strokeWidth="2.5" className="text-primary" opacity="0.3"/>
                
                {/* Left Leaf */}
                <g>
                  <path d="M30 35 Q25 40 28 50 Q35 48 38 40" fill="currentColor" className="text-primary" opacity="0.7"/>
                  <path d="M28 38 Q26 42 28 48" stroke="currentColor" strokeWidth="1.5" fill="none" className="text-primary/50" strokeLinecap="round"/>
                </g>
                
                {/* Center Leaf */}
                <g>
                  <path d="M40 20 Q35 30 40 45 Q45 30 40 20" fill="currentColor" className="text-primary"/>
                  <path d="M40 25 Q38 32 40 42" stroke="currentColor" strokeWidth="1.2" fill="none" className="text-primary/30" strokeLinecap="round"/>
                </g>
                
                {/* Right Leaf */}
                <g>
                  <path d="M50 35 Q55 40 52 50 Q45 48 42 40" fill="currentColor" className="text-primary" opacity="0.7"/>
                  <path d="M52 38 Q54 42 52 48" stroke="currentColor" strokeWidth="1.5" fill="none" className="text-primary/50" strokeLinecap="round"/>
                </g>
                
                {/* Recycling Arrow */}
                <g>
                  <path d="M40 50 L45 62 L50 50" stroke="currentColor" strokeWidth="2" fill="none" className="text-primary" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="40" cy="58" r="2" fill="currentColor" className="text-primary"/>
                </g>
                
                {/* Bottom Accent */}
                <path d="M25 68 Q40 75 55 68" stroke="currentColor" strokeWidth="2" fill="none" className="text-primary/40" strokeLinecap="round" opacity="0.6"/>
              </svg>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">CompostMate</h1>
            <p className="text-sm text-muted-foreground">Turning waste into gold</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Input */}
            <div>
              <label htmlFor="email" className="block text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                placeholder="name@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => setFocusedField('email')}
                onBlur={() => setFocusedField(null)}
                className={`w-full bg-input border rounded-lg px-4 py-3 text-sm text-foreground placeholder-muted-foreground transition-all ${
                  focusedField === 'email' ? 'border-primary ring-2 ring-primary/30' : 'border-border hover:border-border'
                }`}
                required
              />
            </div>

            {/* Password Input */}
            <div>
              <label htmlFor="password" className="block text-xs font-medium text-muted-foreground mb-2 uppercase tracking-wide">
                Password
              </label>
              <input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onFocus={() => setFocusedField('password')}
                onBlur={() => setFocusedField(null)}
                className={`w-full bg-input border rounded-lg px-4 py-3 text-sm text-foreground placeholder-muted-foreground transition-all ${
                  focusedField === 'password' ? 'border-primary ring-2 ring-primary/30' : 'border-border hover:border-border'
                }`}
                required
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-primary text-primary-foreground font-semibold rounded-lg py-3 px-4 mt-6 transition-all duration-200 hover:opacity-90 active:scale-95"
            >
              {isLogin ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3 my-8">
            <div className="flex-1 h-px bg-border"></div>
            <span className="text-xs text-muted-foreground font-medium">OR</span>
            <div className="flex-1 h-px bg-border"></div>
          </div>

          {/* Google Button */}
          <button
            className="w-full bg-secondary border border-border rounded-lg py-3 px-4 flex items-center justify-center gap-3 text-foreground font-medium text-sm transition-all duration-200 hover:bg-secondary/80 active:scale-95"
            onClick={() => console.log('Google Sign In')}
          >
            {/* Google Logo G */}
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span>Continue with Google</span>
          </button>

          {/* Toggle Link */}
          <div className="text-center mt-8">
            <span className="text-sm text-muted-foreground">
              {isLogin ? "Don't have an account? " : 'Already have an account? '}
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-primary font-semibold hover:text-primary/80 transition-colors"
              >
                {isLogin ? 'Sign Up' : 'Sign In'}
              </button>
            </span>
          </div>
        </div>

        {/* Footer Info */}
        <p className="text-center text-xs text-muted-foreground mt-6">
          Sustainable waste management made simple
        </p>
      </div>
    </div>
  );
}
