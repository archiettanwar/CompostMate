'use client';

import { useState } from 'react';

export default function DesktopDashboard() {
  const [activeNav, setActiveNav] = useState('home');

  const navItems = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'log', label: 'Log Waste', icon: '📝' },
    { id: 'bot', label: 'CompostBot', icon: '💬' },
    { id: 'leaderboard', label: 'Leaderboard', icon: '🏆' },
    { id: 'badges', label: 'Badges', icon: '⭐' },
    { id: 'analytics', label: 'Analytics', icon: '📊' },
    { id: 'profile', label: 'Profile', icon: '👤' },
  ];

  const getDateString = () => {
    const today = new Date();
    return today.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-white" style={{ backgroundColor: '#F9FBF9' }}>
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-screen w-60 border-r border-gray-200" style={{ backgroundColor: '#1A5C38' }}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="px-6 py-8">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🌱</span>
              <h1 className="text-xl font-bold text-white">CompostMate</h1>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveNav(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeNav === item.id
                    ? 'bg-white text-gray-900'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                <span className="text-lg">{item.icon}</span>
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* User Avatar at Bottom */}
          <div className="px-4 py-4 border-t border-white/20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white font-bold">
                U
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-medium text-sm truncate">User Name</p>
                <p className="text-white/70 text-xs truncate">user@example.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-60 p-8">
        {/* Top Bar */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Good morning 👋</h1>
          <p className="text-gray-600 font-medium">{getDateString()}</p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          {/* XP Card */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-gray-600 text-sm font-medium mb-2">Total XP</p>
            <p className="text-3xl font-bold text-gray-900">0 XP</p>
          </div>

          {/* Level Card */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-gray-600 text-sm font-medium mb-2">Level</p>
            <p className="text-3xl font-bold text-gray-900">Level 1</p>
            <p className="text-sm text-gray-600 mt-1">Seedling 🌱</p>
          </div>

          {/* Streak Card */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-gray-600 text-sm font-medium mb-2">Streak</p>
            <p className="text-3xl font-bold text-gray-900">0 days</p>
            <p className="text-sm text-gray-600 mt-1">🔥</p>
          </div>

          {/* Waste Diverted Card */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <p className="text-gray-600 text-sm font-medium mb-2">Waste Diverted</p>
            <p className="text-3xl font-bold text-gray-900">0 kg</p>
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-3 gap-6">
          {/* Left Column (60%) */}
          <div className="col-span-2 space-y-6">
            {/* Maturity Tracker */}
            <div className="bg-white rounded-2xl shadow-sm p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Maturity Tracker</h2>
              <div className="flex flex-col items-center justify-center py-12">
                <div className="relative w-32 h-32 mb-6">
                  <svg className="w-full h-full" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="55" fill="none" stroke="#e5e7eb" strokeWidth="8" />
                    <circle
                      cx="60"
                      cy="60"
                      r="55"
                      fill="none"
                      stroke="#1A5C38"
                      strokeWidth="8"
                      strokeDasharray="0 345"
                      strokeLinecap="round"
                    />
                    <text x="60" y="65" textAnchor="middle" fontSize="24" fontWeight="bold" fill="#1a1a1a">
                      0%
                    </text>
                  </svg>
                </div>
                <p className="text-lg font-semibold text-gray-900 mb-2">No active bin</p>
                <p className="text-gray-600 mb-6 text-center">Set up your first composting bin to get started</p>
                <button
                  className="px-6 py-2 rounded-lg font-medium text-white transition-colors"
                  style={{ backgroundColor: '#1A5C38' }}
                  onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.9')}
                  onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
                >
                  Set up your bin
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-2xl shadow-sm p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Recent Activity</h2>
              <div className="flex flex-col items-center justify-center py-12">
                <p className="text-gray-600 text-center mb-4">No activity yet</p>
                <p className="text-gray-500 text-sm text-center max-w-xs">
                  Start by logging your first waste to see your activity appear here
                </p>
              </div>
            </div>
          </div>

          {/* Right Column (40%) */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-2xl shadow-sm p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button
                  className="w-full py-3 px-4 rounded-lg font-medium text-white transition-colors"
                  style={{ backgroundColor: '#1A5C38' }}
                  onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.9')}
                  onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
                >
                  📝 Log Waste
                </button>
                <button
                  className="w-full py-3 px-4 rounded-lg font-medium text-gray-900 border-2 border-gray-300 hover:bg-gray-50 transition-colors"
                >
                  💬 Ask CompostBot
                </button>
                <button
                  className="w-full py-3 px-4 rounded-lg font-medium text-gray-900 border-2 border-gray-300 hover:bg-gray-50 transition-colors"
                >
                  📸 Analyze Compost
                </button>
              </div>
            </div>

            {/* C:N Ratio */}
            <div className="bg-white rounded-2xl shadow-sm p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">C:N Ratio</h2>
              <div className="flex flex-col items-center justify-center py-8">
                <p className="text-4xl font-bold text-gray-300 mb-2">—</p>
                <p className="text-gray-600 text-sm text-center">Log waste to see your C:N ratio</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
