'use client';

import { useState } from 'react';

export default function Dashboard() {
  const [activeNav, setActiveNav] = useState('home');

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Top Navigation */}
      <div className="sticky top-0 z-40 bg-card border-b border-border px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" className="text-primary"/>
            <path d="M12 6 Q12 10 14 14 Q12 13 12 16" stroke="currentColor" strokeWidth="2" fill="none" className="text-primary" strokeLinecap="round"/>
          </svg>
          <span className="font-bold text-lg text-foreground">CompostMate</span>
        </div>
        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-semibold text-primary">
          AM
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        
        {/* Greeting Section */}
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-1">Good morning, Archiet 👋</h2>
          <p className="text-sm text-muted-foreground">Your compost is doing great!</p>
        </div>

        {/* XP Progress Card */}
        <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Level 2</p>
              <h3 className="text-lg font-bold text-primary">Sprout 🌿</h3>
            </div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20">
              <span className="text-sm font-semibold text-amber-500">🔥 7 day streak</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="h-3 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-primary w-1/2 rounded-full"></div>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Progress</span>
              <span className="font-semibold text-foreground">250 / 500 XP</span>
            </div>
          </div>
        </div>

        {/* Maturity Circle Card */}
        <div className="bg-card rounded-2xl border border-border p-6 text-center space-y-4">
          <h3 className="font-bold text-foreground">Compost Maturity</h3>
          
          <div className="flex justify-center">
            <div className="relative w-40 h-40">
              {/* Circular Progress */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
                <circle cx="80" cy="80" r="70" fill="none" stroke="currentColor" strokeWidth="8" className="text-secondary"/>
                <circle cx="80" cy="80" r="70" fill="none" stroke="currentColor" strokeWidth="8" className="text-primary" strokeDasharray={`${70 * Math.PI * 2 * 0.42} ${70 * Math.PI * 2}`} strokeLinecap="round"/>
              </svg>
              
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="text-4xl font-bold text-foreground">42%</p>
                <p className="text-xs text-muted-foreground">Thermophilic</p>
              </div>
            </div>
          </div>

          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">Est. 18 days remaining</p>
            <p className="text-sm font-semibold text-foreground">Active Bin: Balcony Bin 🪣</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <button className="bg-primary text-primary-foreground font-semibold rounded-xl py-3 px-4 flex items-center justify-center gap-2 transition-all hover:opacity-90 active:scale-95">
            <span>📝</span>
            <span>Log Waste</span>
          </button>
          <button className="bg-secondary border border-primary text-primary font-semibold rounded-xl py-3 px-4 flex items-center justify-center gap-2 transition-all hover:bg-secondary/80 active:scale-95">
            <span>💬</span>
            <span>Ask CompostBot</span>
          </button>
        </div>

        {/* Recent Activity */}
        <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
          <h3 className="font-bold text-foreground text-lg">Recent Activity</h3>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3 pb-4 border-b border-border">
              <span className="text-2xl">🍃</span>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">Added greens</p>
                <p className="text-xs text-muted-foreground">0.5kg · 2h ago</p>
              </div>
            </div>

            <div className="flex items-center gap-3 pb-4 border-b border-border">
              <span className="text-2xl">💨</span>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">Turned the pile</p>
                <p className="text-xs text-muted-foreground">Yesterday</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-2xl">🍂</span>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">Added browns</p>
                <p className="text-xs text-muted-foreground">1.2kg · 2 days ago</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border flex items-center justify-around px-4 py-4 max-w-2xl mx-auto">
        <button onClick={() => setActiveNav('home')} className={`flex flex-col items-center gap-1 py-2 ${activeNav === 'home' ? 'text-primary' : 'text-muted-foreground'}`}>
          <span className="text-2xl">🏠</span>
          <span className="text-xs font-medium">Home</span>
        </button>
        <button onClick={() => setActiveNav('log')} className={`flex flex-col items-center gap-1 py-2 ${activeNav === 'log' ? 'text-primary' : 'text-muted-foreground'}`}>
          <span className="text-2xl">📝</span>
          <span className="text-xs font-medium">Log</span>
        </button>
        <button onClick={() => setActiveNav('chat')} className={`flex flex-col items-center gap-1 py-2 ${activeNav === 'chat' ? 'text-primary' : 'text-muted-foreground'}`}>
          <span className="text-2xl">💬</span>
          <span className="text-xs font-medium">Chat</span>
        </button>
        <button onClick={() => setActiveNav('leaderboard')} className={`flex flex-col items-center gap-1 py-2 ${activeNav === 'leaderboard' ? 'text-primary' : 'text-muted-foreground'}`}>
          <span className="text-2xl">🏆</span>
          <span className="text-xs font-medium">Leaderboard</span>
        </button>
        <button onClick={() => setActiveNav('profile')} className={`flex flex-col items-center gap-1 py-2 ${activeNav === 'profile' ? 'text-primary' : 'text-muted-foreground'}`}>
          <span className="text-2xl">👤</span>
          <span className="text-xs font-medium">Profile</span>
        </button>
      </div>
    </div>
  );
}
